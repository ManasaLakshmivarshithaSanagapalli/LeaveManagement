﻿namespace LeaveManagementAPI.DTOs.Login
{
    public class ForgetPasswordDto
    {
        public string Email { get; set; }
    }
}
